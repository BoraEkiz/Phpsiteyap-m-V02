<?php
session_start();

// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emlakkk";

// MySQLi Bağlantısı
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// PDO Bağlantısı
$host = 'localhost';
$db = 'emlakkk';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Kullanıcı adı oturumdan alınır
$username = isset($_SESSION['username']) ? $_SESSION['username'] : '';

// Çıkış işlemi
if (isset($_GET['logout']) && $_GET['logout'] == 'true') {
    session_unset();
    session_destroy();
    header("Location: index.php");
    exit;
}

// Yorum ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit_comment'])) {
    if (isset($_SESSION['username'])) {
        $comment = $conn->real_escape_string($_POST['comment']);
        $memleket_id = $conn->real_escape_string($_POST['memleket_id']);
        $username = $conn->real_escape_string($_SESSION['username']);  // Get the username from the session

        $sql = "INSERT INTO yorumlar (username, comment, memleket_id) VALUES ('$username', '$comment', '$memleket_id')";
        if ($conn->query($sql) === TRUE) {
            echo "Yorum başarıyla eklendi.";
        } else {
            echo "Hata: " . $sql . "<br>" . $conn->error;
        }
    } else {
        echo "Yorum yapmak için giriş yapmalısınız.";
    }
}

// Kategori seçimi yapıldı mı kontrol edin
if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['kategori'])) {
    $kategori = $_GET['kategori'];

    // İlanları veritabanından seç
    $stmt = $pdo->prepare('SELECT * FROM ilanlar WHERE kategori = :kategori');
    $stmt->execute(['kategori' => $kategori]);
    $ilanlar = $stmt->fetchAll();
} else {
    // Kategori seçimi yapılmadıysa, tüm ilanları listele
    $stmt = $pdo->query('SELECT * FROM ilanlar');
    $ilanlar = $stmt->fetchAll();
}

?>



<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emlak Sitesi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            line-height: 1.6;
            margin: 0;
            padding: 0;

            
        }

        

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            font-size: 36px;
            margin-bottom: 10px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin-left: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            color: #ddd;
        }

        .auth-buttons {
            margin-left: auto;
        }

        .auth-buttons a {
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            transition: background-color 0.3s ease;
            margin-left: 20px;
        }

        .auth-buttons .login {
            background-color: #4CAF50;
        }

        .auth-buttons .login:hover {
            background-color: #45a049;
        }

        .auth-buttons .register {
            background-color: #008CBA;
        }

        .auth-buttons .register:hover {
            background-color: #007bb5;
        }

        .auth-buttons .profile, .auth-buttons .logout {
            background-color: #f44336;
        }

        .auth-buttons .profile:hover, .auth-buttons .logout:hover {
            background-color: #d32f2f;
        }

        .search {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
        }

        .search h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .search form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .search input[type="text"], .search select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 300px;
        }

        .search button {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .search button:hover {
            background-color: #555;
        }

        .listings {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
        }

        .listing-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: calc(33.33% - 20px); /* Burayı değiştirdim */
            padding: 20px;
            transition: transform 0.3s ease;
        }

        .listing-card:hover {
            transform: translateY(-5px);
        }

        .listing-card img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }
        .listing-card2 img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }


        footer {
            background-color: #333;
            color: #fff;
            padding: 1px 0;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        footer p {
            font-size: 16px;
        }
    </style>
</head>
<body>
<header>
    <div class="container">
        <div>
            <h1>Emlak Sitesi</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Anasayfa</a></li>
                <li><a href="ilanlarr.php">İlanlar</a></li>
                <li><a href="about.php">Hakkımızda</a></li>
                <li><a href="contact.php">İletişim</a></li>
            </ul>
        </nav>
        <div class="auth-buttons">
            <?php if(isset($_SESSION['username'])): ?>
                <a href="profil.php" class="profile">Profil</a>
                <a href="?logout=true" class="logout">Çıkış Yap</a>
            <?php else: ?>
                <a href="register.php" class="register">Kayıt Ol</a>
                <a href="login.php" class="login">Giriş Yap</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<section class="search">
    <div class="container">
        <h2>Aradığınız Evi Bulun</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="GET">
        <select name="kategori">
    <?php
    // Veritabanından kategorileri çek
    $stmt = $pdo->query('SELECT DISTINCT kategori FROM ilanlar');
    $kategoriler = $stmt->fetchAll(PDO::FETCH_COLUMN);
    
    // Kategorileri seçenekler olarak listele
    foreach ($kategoriler as $kategori) {
        echo '<option value="' . $kategori . '">' . $kategori . '</option>';
    }
    ?>
</select>
    <button type="submit">Ara</button>
</form>
    </div>
</section>
<section class="listings">
    <div class="container">
        <div class="listings">
            <?php foreach ($ilanlar as $ilan): ?>
                <div class="listing-card">
                    <img src="images/<?php echo $ilan['resim']; ?>" alt="İlan Resmi">
                    <h3><?php echo $ilan['baslik']; ?></h3>
                    <p><?php echo $ilan['aciklama']; ?></p>
                    <p><strong>Fiyat: </strong><?php echo $ilan['fiyat']; ?> TL</p>
                    <p><strong>Tür: </strong><?php echo $ilan['kategori']; ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</section>
<footer>
    <div class="container">
        <p>&copy; 2024 Emlak Sitesi. Tüm Hakları Saklıdır.</p>
    </div>



    
</footer>
</body>
</html>
