<?php
session_start();

// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emlakkk";

// MySQLi Bağlantısı
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// PDO Bağlantısı
$host = 'localhost';
$db = 'emlakkk';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}

// Kullanıcı adı oturumdan alınır
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit;
}

$username = $_SESSION['username'];

// Kullanıcı bilgilerini çekme
$stmt = $pdo->prepare('SELECT * FROM user WHERE username = ?');
$stmt->execute([$username]);
$user = $stmt->fetch();

// Profil güncelleme işlemi
$message = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profile'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $current_password = $_POST['current_password'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Şifre doğrulama
    if (password_verify($current_password, $user['password'])) {
        if ($new_password === $confirm_password) {
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $update_stmt = $pdo->prepare('UPDATE user SET name = ?, email = ?, password = ? WHERE username = ?');
            if ($update_stmt->execute([$name, $email, $hashed_password, $username])) {
                $message = "Profil başarıyla güncellendi.";
                // Kullanıcı bilgilerini tekrar çek
                $stmt->execute([$username]);
                $user = $stmt->fetch();
            } else {
                $message = "Profil güncellenirken bir hata oluştu.";
            }
        } else {
            $message = "Yeni şifreler eşleşmiyor.";
        }
    } else {
        $message = "Mevcut şifre yanlış.";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profil - Emlak Sitesi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            line-height: 1.6;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .message {
            text-align: center;
            margin-bottom: 20px;
            color: green;
        }
        .error {
            color: red;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 500px;
            margin: 0 auto;
        }
        label {
            font-weight: bold;
        }
        input {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Profil Güncelle</h2>
        <?php if($message): ?>
            <p class="message"><?php echo $message; ?></p>
        <?php endif; ?>
        <form method="post" action="profil.php">
            <label for="name">İsim</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($user['username']); ?>" required>

            <label for="email">E-posta</label>
            <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required>

            <label for="current_password">Mevcut Şifre</label>
            <input type="password" id="current_password" name="current_password" required>

            <label for="new_password">Yeni Şifre</label>
            <input type="password" id="new_password" name="new_password">

            <label for="confirm_password">Yeni Şifre (Tekrar)</label>
            <input type="password" id="confirm_password" name="confirm_password">

            <button type="submit" name="update_profile">Güncelle</button>
        </form>
    </div>
</body>
</html>
