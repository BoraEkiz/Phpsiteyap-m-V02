<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emlak Sitesi</title>
    <style>* {
    margin: 0;
    padding: 0;
    
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    line-height: 1.6;
}

.container {
    width: 80%;
    margin: 0 auto;
}

header {
    background-color: #3333;
    color: #fff;
    padding: 20px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h1 {
    margin-left: 20px;
}

nav {
    display: flex;
    align-items: center;
    flex-grow: 1;
    justify-content: space-between;
}

nav ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

nav ul li {
    display: inline;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}

.auth-buttons {
    display: flex;
    gap: 10px;
}

.auth-buttons a {
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    display: inline-block;
    transition: background-color 0.3s ease;
}

.auth-buttons .login {
    background-color: #4CAF50;
}

.auth-buttons .login:hover {
    background-color: #45a049;
}

.auth-buttons .register {
    background-color: #008CBA;
}

.auth-buttons .register:hover {
    background-color: #007bb5;
}

.auth-buttons .profile, .auth-buttons .logout {
    background-color: #f44336;
}

.auth-buttons .profile:hover, .auth-buttons .logout:hover {
    background-color: #d32f2f;
}

.search {
    background-color: #f4f4f4;
    padding: 30px 0;
    text-align: center;
}

.search h2 {
    margin-bottom: 20px;
}

.search form {
    display: flex;
    justify-content: center;
    gap: 10px;
}

.search input, .search select, .search button {
    padding: 10px;
    font-size: 16px;
}

.listings {
    padding: 30px 0;
}

.listings h2 {
    text-align: center;
    margin-bottom: 20px;
}

.listing-card {
    border: 1px solid #ddd;
    padding: 20px;
    margin: 20px 0;
    text-align: center;
}

.listing-card img {
    max-width: 100%;
    height: auto;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    margin-top: 20px;
}
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    line-height: 1.6;
}

.containerr {
    width: 30%;
    margin: 0 auto;
 -
}

header {
    background-color: #333;
    color: #fff;
    padding: 20px 0;
}

header h1 {
    margin-left: 20px;
}

nav ul {
    list-style: none;
    display: flex;
}

nav ul li {
    margin-right: 20px;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}

.about {
    padding: 30px 0;
}

.about h2 {
    margin-bottom: 20px;
}

.about p {
    margin-bottom: 20px;
}

.about h3 {
    margin-bottom: 10px;
}
footer {
    background-color: #333;
    color: #fff;
    padding: 20px;
    text-align: center;
    position: fixed; /* Footer'ın sabit konumlandırılması */
    bottom: 0; /* Sayfanın altına sabitleme */
    width: 100%; /* Genişliğin tam sayfa boyutunda olması */
}

</style>
</head>
<body>
<header>
    <div class="container">
        <h1>Emlak Sitesi</h1>
        <nav>
        <ul>
                <li><a href="index.php">Anasayfa</a></li>
                <li><a href="ilanlarr.php">İlanlar</a></li>
                <li><a href="about.php">Hakkımızda</a></li>
                <li><a href="contact.php">İletişim</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['username'])): ?>
                    <a href="profil.php" class="profile">Profil</a>
                    <a href="?logout=true" class="logout">Çıkış Yap</a>
                <?php else: ?>
                    <a href="login.php" class="login">Giriş Yap</a>
                    <a href="register.php" class="register">Kayıt Ol</a>
                <?php endif; ?>
            </div>
        </nav>
    </div>
</header>

<section class="about">
    <div class="containerr">
        <h2>Hakkımızda</h2>
        <p>Emlak Sitesi, ev arayışı içerisinde olan insanlara kolaylık sağlamak için kurulmuş bir platformdur. Amacımız, kullanıcıların aradıkları evleri kolaylıkla bulmalarını sağlamak ve güvenilir bir ortamda ilan yayınlamalarına olanak tanımaktır.</p>
        <h3>Misyonumuz</h3>
        <p>Misyonumuz, kullanıcılarımıza güvenilir, kullanıcı dostu ve yenilikçi bir platform sunmaktır. Her kullanıcının ihtiyaçlarına uygun evi bulmasına yardımcı olmak ve emlak sektöründe güvenilir bir marka olmaktır.</p>
        <h3>Gelecek Vaatlerimiz</h3>
        <p>Gelecekte, platformumuzu sürekli olarak geliştirerek daha fazla özellik eklemeyi ve kullanıcı deneyimini iyileştirmeyi hedefliyoruz. Ayrıca, daha geniş bir kullanıcı kitlesine ulaşmayı ve emlak sektöründe lider bir konuma gelmeyi planlıyoruz.</p>
    </div>
</section>


    <footer style="background-color: #333; color: #fff; padding: 20px; text-align: center;">
    <p>&copy; 2024 Memleket Blog. Tüm hakları saklıdır.</p>
</footer>

</body>
</html>
