<?php
session_start();

// Hata raporlamayı etkinleştir
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emlakkk";

// PDO Bağlantısı
$host = 'localhost';
$db = 'emlakkk';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}


// İlan ekleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_ilan'])) {
    $baslik = $_POST['baslik'];
    $aciklama = $_POST['aciklama'];
    $fiyat = $_POST['fiyat'];
    $resim = $_FILES['resim']['name'];
    $kategori = $_POST['kategori'];
    $target_dir = "images/";
    $target_file = $target_dir . basename($resim);

    // Hedef dizinin yazma izni olup olmadığını kontrol et
    if (!is_writable($target_dir)) {
        echo "Hedef dizin yazılabilir değil.";
        exit;
    }

    if (move_uploaded_file($_FILES['resim']['tmp_name'], $target_file)) {
        $stmt = $pdo->prepare('INSERT INTO ilanlar (baslik, aciklama, fiyat, resim, kategori) VALUES (?, ?, ?, ?, ?)');
        if ($stmt->execute([$baslik, $aciklama, $fiyat, $resim, $kategori])) {
            echo "İlan başarıyla eklendi.";
        } else {
            echo "İlan eklenirken bir hata oluştu.";
        }
    } else {
        // Hata kodunu al ve anlamlı bir mesaj yazdır
        $error_code = $_FILES['resim']['error'];
        echo "Resim yüklenirken bir hata oluştu. Hata kodu: " . $error_code;
    }
}



// İlan güncelleme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_ilan'])) {
    $id = $_POST['id'];
    $baslik = $_POST['baslik'];
    $aciklama = $_POST['aciklama'];
    $fiyat = $_POST['fiyat'];
    $resim = $_FILES['resim']['name'];
    $target_dir = "images/";
    $target_file = $target_dir . basename($resim);

    if ($resim) {
        if (move_uploaded_file($_FILES['resim']['tmp_name'], $target_file)) {
            $stmt = $pdo->prepare('UPDATE ilanlar SET baslik = ?, aciklama = ?, fiyat = ?, resim = ? WHERE id = ?');
            if ($stmt->execute([$baslik, $aciklama, $fiyat, $resim, $id])) {
                echo "İlan başarıyla güncellendi.";
            } else {
                echo "İlan güncellenirken bir hata oluştu.";
            }
        } else {
            $error_code = $_FILES['resim']['error'];
            echo "Resim yüklenirken bir hata oluştu. Hata kodu: " . $error_code;
        }
    } else {
        $stmt = $pdo->prepare('UPDATE ilanlar SET baslik = ?, aciklama = ?, fiyat = ? WHERE id = ?');
        if ($stmt->execute([$baslik, $aciklama, $fiyat, $id])) {
            echo "İlan başarıyla güncellendi.";
        } else {
            echo "İlan güncellenirken bir hata oluştu.";
        }
    }
}

// İlan silme işlemi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_ilan'])) {
    $id = $_POST['id'];
    $stmt = $pdo->prepare('DELETE FROM ilanlar WHERE id = ?');
    if ($stmt->execute([$id])) {
        echo "İlan başarıyla silindi.";
    } else {
        echo "İlan silinirken bir hata oluştu.";
    }
}
$kategoriler = ['Satılık', 'Kiralık', 'Arsa']; // Kategori seçeneklerini tanımlıyoruz


// İlanları listele
$stmt = $pdo->query('SELECT * FROM ilanlar');
$ilanlar = $stmt->fetchAll();




?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İlan Yönetimi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            line-height: 1.6;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
            max-width: 500px;
            margin: 0 auto 20px;
        }
        label {
            font-weight: bold;
        }
        input, textarea {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            padding: 10px;
            font-size: 16px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
            border-radius: 5px;
        }
        button:hover {
            background-color: #45a049;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f4f4f4;
        }
        img {
            width: 100px;
            height: auto;
        }




        
    </style>
</head>
<body>
    <div class="container">
        <h2>İlan Ekle</h2>
        <form method="post" action="ilanlar.php" enctype="multipart/form-data">
            <label for="baslik">Başlık</label>
            <input type="text" id="baslik" name="baslik" required>

            <label for="aciklama">Açıklama</label>
            <textarea id="aciklama" name="aciklama" required></textarea>

            <label for="fiyat">Fiyat</label>
            <input type="number" id="fiyat" name="fiyat" step="0.01" required>

            <label for="resim">Resim</label>
            <input type="file" id="resim" name="resim" required>

            <label for="kategori">Kategori</label>
                <select id="kategori" name="kategori" required>
                <option value="" disabled selected>Kategori Seçiniz</option>
            <?php foreach ($kategoriler as $kategori): ?>
        <option value="<?php echo $kategori; ?>"><?php echo $kategori; ?></option>
    <?php endforeach; ?>
</select>


            <button type="submit" name="add_ilan">Ekle</button>
        </form>

        <h2>İlanlar</h2>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Başlık</th>
                    <th>Açıklama</th>
                    <th>Fiyat</th>
                    <th>Kategori</th>
                    <th>Resim</th>
                    <th>İşlemler</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($ilanlar as $ilan): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($ilan['id']); ?></td>
                        <td><?php echo htmlspecialchars($ilan['baslik']); ?></td>
                        <td><?php echo htmlspecialchars($ilan['aciklama']); ?></td>
                        <td><?php echo htmlspecialchars($ilan['fiyat']); ?> TL</td>
                        <td><?php echo htmlspecialchars($ilan['kategori']); ?></td>

                        
                        <td><img src="images/<?php echo htmlspecialchars($ilan['resim']); ?>" alt="<?php echo htmlspecialchars($ilan['baslik']); ?>"></td>
                        <td>
                            <form method="post" action="ilanlar.php" style="display:inline-block;">
                                <input type="hidden" name="id" value="<?php echo htmlspecialchars($ilan['id']); ?>">
<button type="submit" name="delete_ilan">Sil</button>
</form>
<form method="post" action="ilanlar.php" enctype="multipart/form-data" style="display:inline-block;">
<input type="hidden" name="id" value="<?php echo htmlspecialchars($ilan['id']); ?>">
<input type="text" name="baslik" value="<?php echo htmlspecialchars($ilan['baslik']); ?>" required>
<textarea name="aciklama" required><?php echo htmlspecialchars($ilan['aciklama']); ?></textarea>
<input type="number" name="fiyat" value="<?php echo htmlspecialchars($ilan['fiyat']); ?>" step="0.01" required>
<input type="file" name="resim">
<button type="submit" name="update_ilan">Güncelle</button>
</form>
</td>
</tr>
<?php endforeach; ?>
</tbody>
</table>
</div>

</body>
</html>