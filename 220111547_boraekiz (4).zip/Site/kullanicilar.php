<?php
session_start();
if(!isset($_SESSION['username'])){
    header("login.php");
    exit();
}
$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "emlakkk";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM kullanicilar WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION["loggedin"] = true;
            header("Location: admin.php");
            exit;
        } else {
            $error = "Şifreniz yanlış.";
        }
    } else {
        $error = "Kullanıcı adı bulunamadı.";
    }
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Paneli</title>
    <link rel="stylesheet" href="style.css">
    <style>
 body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 20px;
        }

        nav {
            background-color: #444;
            color: #fff;
            padding: 10px;
        }

        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
        }

        nav ul li {
            display: inline;
            margin-right: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
        }

        footer {
            background-color: #333;
            color: #fff;
            text-align: center;
            padding: 10px;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        .form-container {
            margin: 50px auto;
            width: 300px;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        .error {
            color: red;
            margin-bottom: 10px;
        }

        form label {
            display: block;
            margin-bottom: 5px;
        }

        form input[type="text"],
        form input[type="password"] {
            width: 100%;
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            box-sizing: border-box;
        }

        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #333;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }    </style>
</head>
<body>
<?php if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true): ?>
    <header>
        <h1>Admin Paneli</h1>
    </header>
    <nav>
    <ul class="sidebar-menu">
            <li><a href="index.php">Anasayfa</a></li>
            <li><a href="kullanicilar.php">Kullanıcı</a></li>
            <li><a href="ilanlar.php">İlan</a></li>
        </ul>
    </nav>
    <main>
        <?php
  $servername = "localhost";
  $username = "root";
  $password = ""; 
  $dbname = "emlakkk";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Bağlantı hatası: " . $conn->connect_error);
        }

        $sql = "SELECT id, username, password FROM user";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            echo "<table border='1' align='center'>
                    <tr>
                        <th>ID</th>
                        <th>Kullanıcı Adı</th>
                        <th>Şifre</th>
                        <th>İşlem</th>
                    </tr>";
            while($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row["id"] . "</td>
                        <td>" . $row["username"] . "</td>
                        <td>" . $row["password"] . "</td>
                        <td><a href='?id=" . $row["id"] . "'>Sil</a></td>
                    </tr>";
            }
            echo "</table>";
        } else {
            echo "Hiç kullanıcı bulunamadı.";
        }

        if(isset($_GET['id'])) {
            $id = $_GET['id'];
            $silme_sql = "DELETE FROM user WHERE id=$id";
            if ($conn->query($silme_sql) === TRUE) {
                echo "<p>Kullanıcı başarıyla silindi.</p>";
            } else {
                echo "Silme işlemi başarısız: " . $conn->error;
            }
        }

        $conn->close();
        ?>
    </main>
    <footer>
        &copy; 2024 Admin Paneli
    </footer>
<?php else: ?>
    <div class="form-container">
        <h2>Giriş Yap</h2>
        <?php if ($error) { echo '<div class="error">' . $error . '</div>'; } ?>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="username">Kullanıcı Adı:</label>
            <input type="text" id="username" name="username" required>
            <label for="password">Şifre:</label>
            <input type="password" id="password" name="password" required>
            <input type="submit" value="Giriş Yap">
        </form>
    </div>
<?php endif; ?>
</body>
</html>
