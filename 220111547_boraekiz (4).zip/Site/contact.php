<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>İletişim Formu</title>
    <style>
        .container {
            width: 50%;
            margin: 0 auto;
        }

        form {
            margin-top: 20px;
        }

        label,
        input,
        textarea {
            display: block;
            margin-bottom: 10px;
        }

        input,
        textarea {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
        }

        button {
            padding: 10px 20px;
            background-color: #007bff;
            color: #fff;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>

    <style>* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    font-family: Arial, sans-serif;
}

body {
    line-height: 1.6;
}

.container {
    width: 80%;
    margin: 0 auto;
}

header {
    background-color: #333;
    color: #fff;
    padding: 20px 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

header h1 {
    margin-left: 20px;
}

nav {
    display: flex;
    align-items: center;
    flex-grow: 1;
    justify-content: space-between;
}

nav ul {
    list-style: none;
    display: flex;
    gap: 20px;
}

nav ul li {
    display: inline;
}

nav ul li a {
    color: #fff;
    text-decoration: none;
}

.auth-buttons {
    display: flex;
    gap: 10px;
}

.auth-buttons a {
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    font-size: 16px;
    border-radius: 5px;
    text-decoration: none;
    color: white;
    display: inline-block;
    transition: background-color 0.3s ease;
}

.auth-buttons .login {
    background-color: #4CAF50;
}

.auth-buttons .login:hover {
    background-color: #45a049;
}

.auth-buttons .register {
    background-color: #008CBA;
}

.auth-buttons .register:hover {
    background-color: #007bb5;
}

.auth-buttons .profile, .auth-buttons .logout {
    background-color: #f44336;
}

.auth-buttons .profile:hover, .auth-buttons .logout:hover {
    background-color: #d32f2f;
}

.search {
    background-color: #f4f4f4;
    padding: 30px 0;
    text-align: center;
}

.search h2 {
    margin-bottom: 20px;
}

.search form {
    display: flex;
    justify-content: center;
    gap: 10px;
}

.search input, .search select, .search button {
    padding: 10px;
    font-size: 16px;
}

.listings {
    padding: 30px 0;
}

.listings h2 {
    text-align: center;
    margin-bottom: 20px;
}

.listing-card {
    border: 1px solid #ddd;
    padding: 20px;
    margin: 20px 0;
    text-align: center;
}

.listing-card img {
    max-width: 100%;
    height: auto;
}

footer {
    background-color: #333;
    color: #fff;
    text-align: center;
    padding: 10px 0;
    margin-top: 20px;
}
.iletisim {
    max-width: 600px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #f9f9f9;
}

.iletisim h2 {
    text-align: center;
    margin-bottom: 20px;
}

.iletisim form {
    display: flex;
    flex-direction: column;
}

.iletisim form label {
    font-weight: bold;
    margin-bottom: 5px;
}

.iletisim form input,
.iletisim form textarea {
    padding: 10px;
    margin-bottom: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
}

.iletisim form button {
    padding: 10px 20px;
    font-size: 16px;
    background-color: #4CAF50;
    color: white;
    border: none;
    border-radius: 5px;
    cursor: pointer;
}

.iletisim form button:hover {
    background-color: #45a049;
}
footer {
    background-color: #333;
    color: #fff;
    padding: 20px;
    text-align: center;
    position: fixed; /* Footer'ın sabit konumlandırılması */
    bottom: 0; /* Sayfanın altına sabitleme */
    width: 100%; /* Genişliğin tam sayfa boyutunda olması */
}

</style>
</head>
<body>
<header>
    <div class="container">
        <h1>Emlak Sitesi</h1>
        <nav>
        <ul>
                <li><a href="index.php">Anasayfa</a></li>
                <li><a href="ilanlarr.php">İlanlar</a></li>
                <li><a href="about.php">Hakkımızda</a></li>
                <li><a href="contact.php">İletişim</a></li>
            </ul>
            <div class="auth-buttons">
                <?php if(isset($_SESSION['username'])): ?>
                    <a href="profil.php" class="profile">Profil</a>
                    <a href="?logout=true" class="logout">Çıkış Yap</a>
                <?php else: ?>
                    <a href="login.php" class="login">Giriş Yap</a>
                    <a href="register.php" class="register">Kayıt Ol</a>
                <?php endif; ?>
            </div>
        </nav>
    </div>
</header>
    <div class="iletisim">
        <h2>İletişim Formu</h2>
        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <label for="name">Adınız:</label>
            <input type="text" id="name" name="name" required>

            <label for="email">E-posta Adresiniz:</label>
            <input type="email" id="email" name="email" required>

            <label for="message">Mesajınız:</label>
            <textarea id="message" name="message" required></textarea>

            <button type="submit">Gönder</button>
        </form>
    </div>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $message = $_POST['message'];

        // İletişim bilgilerini burada işleyebilirsiniz.
        // Örneğin, bir veritabanına kaydedebilir veya bir e-posta ile gönderebilirsiniz.
        
        // Bu örnekte sadece ekrana yazdırıyoruz.
        echo "<h2>Gönderilen Bilgiler:</h2>";
        echo "<p><strong>Ad:</strong> " . $name . "</p>";
        echo "<p><strong>E-posta:</strong> " . $email . "</p>";
        echo "<p><strong>Mesaj:</strong> " . $message . "</p>";
    }
    ?>



<footer style="background-color: #333; color: #fff; padding: 20px; text-align: center;">
    <p>&copy; 2024 Memleket Blog. Tüm hakları saklıdır.</p>
</footer>

</body>
</html>
