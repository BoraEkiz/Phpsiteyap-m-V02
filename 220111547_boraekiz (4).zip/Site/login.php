<?php
session_start();

$servername = "localhost";
$username = "root";
$password = ""; 
$dbname = "emlakkk";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

$error = '';

// Şifremi unuttum işlevi
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['forgot_password'])) {
    $email = $_POST['email'];
    
    // E-posta başlığı
    $subject = 'Şifre Sıfırlama';

    // Rastgele bir şifre oluştur
    $new_password = generateRandomString(8); // Örneğin 8 karakterlik bir şifre

    // E-posta içeriği
    $message = "Şifreniz sıfırlandı. Yeni şifreniz: " . $new_password;

    // E-posta başlıkları
    $headers = 'From: your_email@example.com' . "\r\n" .
        'Reply-To: your_email@example.com' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();

    // E-posta gönderme işlemi
    if (mail($email, $subject, $message, $headers)) {
        echo "Şifre sıfırlama bağlantısı e-posta adresinize gönderildi.";
    } else {
        echo "E-posta gönderilirken bir hata oluştu.";
    }
}

// Giriş işlevi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE username = '$username'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        if (password_verify($password, $row['password'])) {
            $_SESSION['username'] = $username;
            header("Location: index.php");
            exit;
        } else {
            $error = "Şifreniz yanlış.";
        }
    } else {
        $error = "Kullanıcı adı bulunamadı.";
    }
}

$conn->close();

// Rastgele şifre oluşturma işlevi
function generateRandomString($length = 8) {
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .form-container {
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 300px;
        }
        .form-container h2 {
            text-align: center;
            margin-bottom: 20px;
        }
        .form-container label {
            display: block;
            margin-bottom: 5px;
        }
        .form-container input[type="text"],
        .form-container input[type="password"],
        .form-container input[type="email"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .form-container input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .form-container input[type="submit"]:hover {
            background-color: #45a049;
        }
        .error {
            color: red;
            text-align: center;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

<div class="form-container">
    <h2>Giriş Yap</h2>
    <?php if ($error) { echo '<div class="error">' . $error . '</div>'; } ?>
    <form action="login.php" method="post">
        <label for="username">Kullanıcı Adı:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Şifre:</label>
        <input type="password" id="password" name="password" required>
        <input type="submit" name="submit" value="Giriş Yap">
    </form>
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
        <input type="hidden" name="forgot_password">
        <input type="email" name="email" placeholder="E-posta adresinizi girin" required>
        <input type="submit" value="Şifremi Unuttum">
    </form>
</div>

</body>
</html>
