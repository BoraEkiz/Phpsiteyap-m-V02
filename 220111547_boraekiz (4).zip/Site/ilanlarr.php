<?php
session_start();

// Veritabanı bağlantı bilgileri
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "emlakkk";

// MySQLi Bağlantısı
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Bağlantı hatası: " . $conn->connect_error);
}

// İlanları çekmek için sorgu
$sql = "SELECT * FROM ilanlar";
$result = $conn->query($sql);

// Eğer sorguda sonuç varsa ilanları çek
$ilanlar = [];
if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $ilanlar[] = $row;
    }
} else {
    echo "İlan bulunamadı.";
}

// Bağlantıyı kapat
$conn->close();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Emlak Sitesi</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            line-height: 1.6;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            display: flex;
            align-items: center;
            justify-content: space-between;
        }

        header {
            background-color: #333;
            color: #fff;
            padding: 20px 0;
            text-align: center;
        }

        header h1 {
            font-size: 36px;
            margin-bottom: 10px;
        }

        nav ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        nav ul li {
            display: inline;
            margin-left: 20px;
        }

        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-size: 18px;
            transition: color 0.3s ease;
        }

        nav ul li a:hover {
            color: #ddd;
        }

        .auth-buttons {
            margin-left: auto;
        }

        .auth-buttons a {
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            text-decoration: none;
            color: white;
            transition: background-color 0.3s ease;
            margin-left: 20px;
        }

        .auth-buttons .login {
            background-color: #4CAF50;
        }

        .auth-buttons .login:hover {
            background-color: #45a049;
        }

        .auth-buttons .register {
            background-color: #008CBA;
        }

        .auth-buttons .register:hover {
            background-color: #007bb5;
        }

        .auth-buttons .profile, .auth-buttons .logout {
            background-color: #f44336;
        }

        .auth-buttons .profile:hover, .auth-buttons .logout:hover {
            background-color: #d32f2f;
        }

        .search {
            background-color: #ddd;
            padding: 20px;
            text-align: center;
            margin-bottom: 20px;
        }

        .search h2 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        .search form {
            display: flex;
            justify-content: center;
            align-items: center;
            gap: 10px;
            margin-bottom: 20px;
        }

        .search input[type="text"], .search select {
            padding: 10px;
            font-size: 16px;
            border: 1px solid #ccc;
            border-radius: 5px;
            width: 300px;
        }

        .search button {
            padding: 10px 20px;
            background-color: #333;
            color: #fff;
            border: none;
            cursor: pointer;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }

        .search button:hover {
            background-color: #555;
        }

        .listings {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-between;
            gap: 20px;
        }

        .listing-card {
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0px 0px 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
            width: calc(33.33% - 20px); /* Burayı değiştirdim */
            padding: 20px;
            transition: transform 0.3s ease;
        }

        .listing-card:hover {
            transform: translateY(-5px);
        }

        .listing-card img {
            width: 100%;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        footer {
            background-color: #333;
            color: #fff;
            padding: 1px 0;
            text-align: center;
            position: fixed;
            bottom: 0;
            width: 100%;
        }

        footer p {
            font-size: 16px;
        }
    </style>
</head>
<body>
<header>
    <div class="container">
        <h1>Emlak Sitesi</h1>
        <nav>
            <ul>
                <li><a href="index.php">Anasayfa</a></li>
                <li><a href="ilanlarr.php">İlanlar</a></li>
                <li><a href="about.php">Hakkımızda</a></li>
                <li><a href="contact.php">İletişim</a></li>
            </ul>
        </nav>
        <div class="auth-buttons">
            <?php if(isset($_SESSION['username'])): ?>
                <a href="profil.php" class="profile">Profil</a>
                <a href="?logout=true" class="logout">Çıkış Yap</a>
            <?php else: ?>
                <a href="login.php" class="login">Giriş Yap</a>
                <a href="register.php" class="register">Kayıt Ol</a>
            <?php endif; ?>
        </div>
    </div>
</header>
<section class="listings">
    <div class="container">
        <?php foreach ($ilanlar as $ilan): ?>
            <div class="listing-card">
                <img src="images/<?php echo $ilan['resim']; ?>" alt="İlan Resmi">
                <h3><?php echo $ilan['baslik']; ?></h3>
                <p><?php echo $ilan['aciklama']; ?></p>
                <p><strong>Fiyat: </strong><?php echo $ilan['fiyat']; ?> TL</p>
            </div>
        <?php endforeach; ?>
    </div>
</section>
<footer>
    <div class="container">
        <p>&copy; 2024 Memleket Blog. Tüm hakları saklıdır.</p>
    </div>
</footer>
</body>
</html>
